package com.example.affirmation.model

data class Affirmation(val stringResourceId: Int)