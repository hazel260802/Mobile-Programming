package com.example.backstacks

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.backstacks.databinding.FragmentQuestion2Binding

class Question2Fragment : Fragment(R.layout.fragment_question2) {

    val args: Question2FragmentArgs by navArgs()
    // Declare a view binding variable
    private var binding: FragmentQuestion2Binding? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize the view binding
        binding = FragmentQuestion2Binding.bind(view)

        // Retrieve the score from Question1Fragment using Safe Args
        val scoreFromQuestion1 = args.score
        // Now you can use scoreFromQuestion1 as needed.

        // Xử lý sự kiện khi nhấn nút Next.
        binding?.nextButton?.setOnClickListener {
            submitAnswers(scoreFromQuestion1)
        }
    }

    private fun submitAnswers(scoreFromQuestion1: Int) {
        // Logic để tính điểm và truyền điểm sang ResultFragment
        val score = calculateScore(scoreFromQuestion1)

        // Chuyển đến Fragment2 và truyền điểm.
        val action = Question2FragmentDirections.actionQuestion2FragmentToQuestion3Fragment(score)
        findNavController().navigate(action)
    }

    private fun calculateScore(scoreFromQuestion1: Int): Int {
        // Add your logic to calculate the score, using scoreFromQuestion1 if needed.
        // In this example, assuming the score is 1 if the user selects the correct option.
        return when {
            binding?.option1RadioButton?.isChecked == true -> scoreFromQuestion1
            binding?.option2RadioButton?.isChecked == true -> scoreFromQuestion1
            binding?.option3RadioButton?.isChecked == true -> scoreFromQuestion1 + 1
            else -> scoreFromQuestion1
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        // Clean up the view binding instance to avoid memory leaks
        binding = null
    }
}

