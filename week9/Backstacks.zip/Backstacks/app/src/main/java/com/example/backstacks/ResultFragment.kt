package com.example.backstacks

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs

class ResultFragment : Fragment(R.layout.fragment_result) {

    private val args: ResultFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Access the score using navArgs.
        val score = args.score

        // Display the score in the TextView.
        view.findViewById<TextView>(R.id.scoreTextView).text = "Score: $score"

        // Handle the event when the Restart button is clicked.
        view.findViewById<Button>(R.id.restartButton).setOnClickListener {
            // Navigate to WelcomeFragment when the Restart button is clicked.
            findNavController().navigate(R.id.action_resultFragment_to_welcomeFragment)
        }
    }
}
