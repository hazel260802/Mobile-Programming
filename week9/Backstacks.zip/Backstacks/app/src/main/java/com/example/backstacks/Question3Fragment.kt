package com.example.backstacks

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.backstacks.databinding.FragmentQuestion3Binding

class Question3Fragment : Fragment(R.layout.fragment_question3) {

    val args: Question3FragmentArgs by navArgs()
    // Declare a view binding variable
    private var binding: FragmentQuestion3Binding? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize the view binding
        binding = FragmentQuestion3Binding.bind(view)


        val scoreFromQuestion2 = args.score

        // Now you can use scoreFromQuestion2 as needed.

        // Xử lý sự kiện khi nhấn nút Next.
        binding?.nextButton?.setOnClickListener {
            submitAnswers(scoreFromQuestion2)
        }
    }

    private fun submitAnswers(scoreFromQuestion2: Int) {
        // Logic để tính điểm và truyền điểm sang ResultFragment
        val score = calculateScore(scoreFromQuestion2)

        // Chuyển đến ResultFragment và truyền điểm.
        val action = Question3FragmentDirections.actionQuestion3FragmentToResultFragment(score)
        findNavController().navigate(action)
    }

    private fun calculateScore(scoreFromQuestion2: Int): Int {
        // Add your logic to calculate the score, using scoreFromQuestion2 if needed.
        // In this example, assuming the score is 1 if the user selects the correct option.
        return when {
            binding?.option1RadioButton?.isChecked == true -> scoreFromQuestion2
            binding?.option2RadioButton?.isChecked == true -> scoreFromQuestion2
            binding?.option3RadioButton?.isChecked == true -> scoreFromQuestion2 + 1
            else -> scoreFromQuestion2
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        // Clean up the view binding instance to avoid memory leaks
        binding = null
    }
}
