package com.example.backstacks

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.backstacks.databinding.FragmentQuestion1Binding

class Question1Fragment : Fragment(R.layout.fragment_question1) {

        private var binding: FragmentQuestion1Binding? = null
        private val args: Question1FragmentArgs by navArgs()

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
                super.onViewCreated(view, savedInstanceState)
                binding = FragmentQuestion1Binding.bind(view)

                val score = args.score

                binding?.nextButton?.setOnClickListener {
                        submitAnswers(score)
                }
        }

        private fun submitAnswers(scoreInitial: Int) {
                val score = calculateScore(scoreInitial)

                // Navigate to Question2Fragment
                val action = Question1FragmentDirections.actionQuestion1FragmentToQuestion2Fragment(score)
                findNavController().navigate(action)
        }

        private fun calculateScore(scoreInitial: Int): Int {
                // Your logic to calculate the score based on user's answers
                // Modify this based on your actual scoring logic
                return when {
                        binding?.option1RadioButton?.isChecked == true -> scoreInitial
                        binding?.option2RadioButton?.isChecked == true -> scoreInitial
                        binding?.option3RadioButton?.isChecked == true -> scoreInitial + 1
                        else -> scoreInitial
                }
        }

        override fun onDestroyView() {
                super.onDestroyView()
                binding = null
        }
}
