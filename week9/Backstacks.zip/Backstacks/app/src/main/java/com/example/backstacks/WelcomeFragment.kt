// WelcomeFragment.kt

package com.example.backstacks

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.backstacks.databinding.FragmentWelcomeBinding

class WelcomeFragment : Fragment(R.layout.fragment_welcome) {

        // Declare a view binding variable
        private var binding: FragmentWelcomeBinding? = null

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
                super.onViewCreated(view, savedInstanceState)

                // Initialize the view binding
                binding = FragmentWelcomeBinding.bind(view)

                // Set up click listener for the start button
                binding?.startButton?.setOnClickListener {
                        navigateToQuestion1()
                }
        }

        private fun navigateToQuestion1() {
                // Navigate to Question1Fragment when the start button is clicked
                findNavController().navigate(R.id.action_welcomeFragment_to_question1Fragment)
        }

        override fun onDestroyView() {
                super.onDestroyView()

                // Clean up the view binding instance to avoid memory leaks
                binding = null
        }
}
