package com.example.myapplication

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Tạo đối tượng Lifecycles Observer
        val myObserver = MyObserver()

        // Đăng ký Observer với Lifecycle của Activity
        lifecycle.addObserver(myObserver)
    }

    inner class MyObserver : DefaultLifecycleObserver {

        override fun onCreate(owner: LifecycleOwner) {
            Log.d("Lifecycle", "Observer - onCreate")
        }

        override fun onStart(owner: LifecycleOwner) {
            Log.d("Lifecycle", "Observer - onStart")
        }

        override fun onResume(owner: LifecycleOwner) {
            Log.d("Lifecycle", "Observer - onResume")
        }

        override fun onPause(owner: LifecycleOwner) {
            Log.d("Lifecycle", "Observer - onPause")
        }

        override fun onStop(owner: LifecycleOwner) {
            Log.d("Lifecycle", "Observer - onStop")
        }

        override fun onDestroy(owner: LifecycleOwner) {
            Log.d("Lifecycle", "Observer - onDestroy")
        }
    }
}
